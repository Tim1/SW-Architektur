package swa.runningeasy.junit;

import java.util.Iterator;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import runningeasy.bom.entities.RunningServicesFactory;
import swa.runningeasy.dtos.VereinDTO;
import swa.runningeasy.services.RunningServices;

public class Organization
{
  RunningServices s = RunningServicesFactory.getInstance();

  @Test
  public void testAnzahlVereine()
  {
    List l = this.s.getVereine();

    TestDataImporter tdi = new TestDataImporter();
    List lff = tdi.getVereine();

    Assert.assertEquals(lff.size(), l.size());
  }

  @Test
  public void testInhaltVereine()
  {
    List l = this.s.getVereine();

    TestDataImporter tdi = new TestDataImporter();
    List lff = tdi.getVereine();

    for (VereinDTO v : l)
    {
      StringBuffer errorMessage = new StringBuffer("Fehlender oder fehlerhafter Verein: ");
      errorMessage.append(v.toString());

      Assert.assertTrue(errorMessage.toString(), isContainedInList(v, lff));
    }
  }

  private boolean isContainedInList(VereinDTO v, List<VereinDTO> list)
  {
    for (Iterator iter = list.iterator(); iter.hasNext(); )
    {
      VereinDTO vil = (VereinDTO)iter.next();
      if (equal(vil, v)) return true;
    }

    return false;
  }

  boolean equal(VereinDTO left, VereinDTO right)
  {
    boolean sameName = false;
    boolean sameStreet = false;
    boolean samePostal = false;
    boolean sameCity = false;
    boolean sameCountry = false;

    if ((left.getName() == null) && (right.getName() == null))
    {
      sameName = true;
    }
    else sameName = left.getName().trim().equals(right.getName().trim());

    if ((left.getStrasse() == null) && (right.getStrasse() == null))
    {
      sameStreet = true;
    }
    else sameStreet = left.getStrasse().trim().equals(right.getStrasse().trim());

    if ((left.getPlz() == null) && (right.getPlz() == null))
    {
      samePostal = true;
    }
    else samePostal = left.getPlz().trim().equals(right.getPlz().trim());

    if ((left.getOrt() == null) && (right.getOrt() == null))
    {
      sameCity = true;
    }
    else sameCity = left.getOrt().trim().equals(right.getOrt().trim());

    if ((left.getLand() == null) && (right.getLand() == null))
    {
      sameCountry = true;
    }
    else sameCountry = left.getLand().trim().equals(right.getLand().trim());

    if ((sameName) && (sameStreet) && (samePostal) && (sameCity) && (sameCountry)) return true;

    return false;
  }
}