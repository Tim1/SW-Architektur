package swa.runningeasy.junit;

import java.util.Date;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import runningeasy.bom.entities.RunningServicesFactory;
import swa.runningeasy.dtos.ListeneintragDTO;
import swa.runningeasy.services.Auswertung;
import swa.runningeasy.services.RunningServices;

public class Resultlist
{
  RunningServices s = RunningServicesFactory.getInstance();

  @Test
  public void testErgebnisliste()
  {
    List l = this.s.getAuswertung(Auswertung.GESAMTERGEBNISLISTE, "30. Kandelberglauf 2011");
    Assert.assertEquals(46L, l.size());

    for (ListeneintragDTO le : l) {
      if (le.getPlatzierung() == 1) { Assert.assertEquals("Hinze", le.getName());
        Assert.assertTrue((le.getLaufzeit().getHours() == 0) && (le.getLaufzeit().getMinutes() == 52) && (le.getLaufzeit().getSeconds() == 2));
      }
      if (le.getPlatzierung() == 9) { Assert.assertEquals("Thoma", le.getName());
        Assert.assertTrue((le.getLaufzeit().getHours() == 0) && (le.getLaufzeit().getMinutes() == 55) && (le.getLaufzeit().getSeconds() == 29));
      }
    }
  }
}