package swa.runningeasy.junit;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import runningeasy.bom.entities.RunningServicesFactory;
import swa.runningeasy.dtos.VeranstaltungDTO;
import swa.runningeasy.services.RunningServices;

public class RunningEvent
{
  RunningServices s = RunningServicesFactory.getInstance();

  @Test
  public void testAnzahlVeranstaltungen()
  {
    List l = this.s.getVeranstaltungen();

    TestDataImporter tdi = new TestDataImporter();
    List lff = tdi.getVeranstaltungen();

    Assert.assertEquals(lff.size(), l.size());
  }

  @Test
  public void testInhaltVeranstaltungen()
  {
    List l = this.s.getVeranstaltungen();

    TestDataImporter tdi = new TestDataImporter();
    List lff = tdi.getVeranstaltungen();

    for (VeranstaltungDTO v : l)
    {
      StringBuffer errorMessage = new StringBuffer("Fehlende oder fehlerhafte Veranstaltung: ");
      errorMessage.append(v.toString());

      Assert.assertTrue(errorMessage.toString(), isContainedInList(v, lff));
    }
  }

  private boolean isContainedInList(VeranstaltungDTO v, List<VeranstaltungDTO> list)
  {
    label126: for (Iterator iter = list.iterator(); iter.hasNext(); 
      return true)
    {
      VeranstaltungDTO vil = (VeranstaltungDTO)iter.next();

      boolean sameName = vil.getName().trim().equals(v.getName().trim());
      boolean sameDate = vil.getDatum().compareTo(v.getDatum()) == 0;
      boolean sameDeadline = vil.getAnmeldeschluss().compareTo(v.getAnmeldeschluss()) == 0;
      boolean sameFee = vil.getStartgebuehr() == v.getStartgebuehr();

      if ((!sameName) || (!sameDate) || (!sameDeadline) || (!sameFee))
        break label126;
    }
    return false;
  }
}