package swa.runningeasy.junit;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.security.CodeSource;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.ProtectionDomain;
import java.util.Formatter;
import org.junit.Assert;

public class Integrity
{
  private final String shaHashFilename = "swa_runningeasy_junit_testdriver.jar.txt";

  public void jarIntegrityTest()
  {
    String sha1hash = calculateJarHash();
    String sha1hashReference = readReferenceHash("swa_runningeasy_junit_testdriver.jar.txt");

    Assert.assertTrue(sha1hash.equals(sha1hashReference));
  }

  private String calculateJarHash()
  {
    Class thisClass = getClass();
    String pathToJar = thisClass.getProtectionDomain().getCodeSource().getLocation().getPath();

    if (pathToJar.endsWith(".jar"))
    {
      try
      {
        MessageDigest sha1 = MessageDigest.getInstance("SHA1");

        FileInputStream fis = new FileInputStream(pathToJar);
        BufferedInputStream bis = new BufferedInputStream(fis);
        DigestInputStream dis = new DigestInputStream(bis, sha1);

        int byteRead = 0;
        do
        {
          byteRead = dis.read();
        }
        while (byteRead != -1);

        byte[] hash = sha1.digest();
        return byteArray2Hex(hash);
      }
      catch (IOException e)
      {
        e.printStackTrace();
      }
      catch (NoSuchAlgorithmException e)
      {
        e.printStackTrace();
      }
    }

    return null;
  }

  private String readReferenceHash(String pathToFile)
  {
    try
    {
      StringBuilder sb = new StringBuilder();

      FileReader fr = new FileReader(pathToFile);

      for (int sinlgeCharacter = 0; (sinlgeCharacter = fr.read()) != -1; )
      {
        sb.append((char)sinlgeCharacter);
      }

      return sb.toString().trim();
    }
    catch (FileNotFoundException e)
    {
      e.printStackTrace();
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }

    return null;
  }

  private String byteArray2Hex(byte[] byteArray)
  {
    Formatter formatter = new Formatter();
    for (byte b : byteArray)
    {
      formatter.format("%02x", new Object[] { Byte.valueOf(b) });
    }
    return formatter.toString();
  }
}