package swa.runningeasy.junit;

import java.util.List;
import org.junit.After;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import runningeasy.bom.entities.RunningServicesFactory;
import swa.runningeasy.services.RunningServices;

public class Initialize
{
  RunningServices s = RunningServicesFactory.getInstance();

  @BeforeClass
  public static void oneTimeSetUp() throws Exception
  {
    TestDataImporter c = new TestDataImporter();
    c.initialize();
  }

  @After
  public void tearDown()
    throws Exception
  {
  }

  @Test
  public void testImport()
  {
    List veranstaltungen = this.s.getVeranstaltungen();
    Assert.assertEquals(2L, veranstaltungen.size());

    List vereine = this.s.getVereine();
    Assert.assertEquals(31L, vereine.size());

    List laeufer = this.s.getLaeufer();
    Assert.assertEquals(46L, laeufer.size());

    String veranstaltung = "30. Kandelberglauf 2011";
    List anmeldungen = this.s.getAnmeldungen(veranstaltung);
    Assert.assertEquals(46L, anmeldungen.size());

    List laufzeiten = this.s.getLaufzeiten(veranstaltung);
    Assert.assertEquals(46L, laufzeiten.size());
  }
}