package swa.runningeasy.junit;

import java.util.Iterator;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import runningeasy.bom.entities.RunningServicesFactory;
import swa.runningeasy.dtos.LaeuferDTO;
import swa.runningeasy.services.RunningServices;

public class Runner
{
  RunningServices s = RunningServicesFactory.getInstance();

  @Test
  public void testAnzahlLaeufer()
  {
    List l = this.s.getLaeufer();

    TestDataImporter tdi = new TestDataImporter();
    List lff = tdi.getLaeufer();

    Assert.assertEquals(lff.size(), l.size());
  }

  @Test
  public void testInhaltLaeufer()
  {
    List l = this.s.getLaeufer();

    TestDataImporter tdi = new TestDataImporter();
    List lff = tdi.getLaeufer();

    for (LaeuferDTO v : l)
    {
      StringBuffer errorMessage = new StringBuffer("Fehlender oder fehlerhafter Verein: ");
      errorMessage.append(v.toString());

      Assert.assertTrue(errorMessage.toString(), isContainedInList(v, lff));
    }
  }

  private boolean isContainedInList(LaeuferDTO l, List<LaeuferDTO> list)
  {
    for (Iterator iter = list.iterator(); iter.hasNext(); )
    {
      LaeuferDTO lil = (LaeuferDTO)iter.next();

      boolean sameName = lil.getName().trim().equals(l.getName().trim());
      boolean sameGivenname = lil.getVorname().trim().equals(l.getVorname().trim());
      boolean sameStreet = lil.getStrasse().trim().equals(l.getStrasse().trim());
      boolean samePostal = lil.getPlz().trim().equals(l.getPlz().trim());
      boolean sameCity = lil.getOrt().trim().equals(l.getOrt().trim());
      boolean sameCountry = lil.getLand().trim().equals(l.getLand().trim());
      boolean sameEmail = lil.getEmail().trim().equals(l.getEmail().trim());
      boolean sameYearofBirth = lil.getGeburtsjahr() == l.getGeburtsjahr();
      boolean sameSex = lil.getGeschlecht() == l.getGeschlecht();
      boolean sameSms = lil.getSms().trim().equals(l.getSms().trim());

      if ((sameName) && (sameGivenname) && (sameStreet) && (samePostal) && 
        (sameCity) && (sameCountry) && (sameEmail) && (sameYearofBirth) && 
        (sameSex) && (sameSms)) {
        return true;
      }
    }
    return false;
  }
}