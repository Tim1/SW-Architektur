package swa.runningeasy.junit;

import java.util.Iterator;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import runningeasy.bom.entities.RunningServicesFactory;
import swa.runningeasy.dtos.AnmeldungDTO;
import swa.runningeasy.dtos.LaeuferDTO;
import swa.runningeasy.dtos.VeranstaltungDTO;
import swa.runningeasy.services.RunningServices;

public class Application
{
  RunningServices s = RunningServicesFactory.getInstance();

  @Test
  public void testAnzahlAnmeldungen()
  {
    TestDataImporter tdi = new TestDataImporter();
    List veranstaltungen = tdi.getVeranstaltungen();

    for (VeranstaltungDTO veranstaltung : veranstaltungen)
    {
      List l = this.s.getAnmeldungen(veranstaltung.getName());

      StringBuffer errorMessage = new StringBuffer("Fehlerhafte Anzahl Anmeldung für Veranstaltung: ");
      errorMessage.append(veranstaltung.getName());

      if (veranstaltung.getName() == "30. Kandelberglauf 2011")
      {
        Assert.assertEquals(errorMessage.toString(), l.size(), 46L);
      }

      if (veranstaltung.getName() == "31. Kandelberglauf 2011")
      {
        Assert.assertEquals(errorMessage.toString(), l.size(), 0L);
      }
    }
  }

  @Test
  public void testInhaltAnmeldung()
  {
    TestDataImporter tdi = new TestDataImporter();
    List veranstaltungen = tdi.getVeranstaltungen();
    Iterator localIterator2;
    for (Iterator localIterator1 = veranstaltungen.iterator(); localIterator1.hasNext(); 
      localIterator2.hasNext())
    {
      VeranstaltungDTO veranstaltung = (VeranstaltungDTO)localIterator1.next();

      List l = this.s.getAnmeldungen(veranstaltung.getName());

      List lff = tdi.getAnmeldungen();

      localIterator2 = l.iterator(); continue; AnmeldungDTO a = (AnmeldungDTO)localIterator2.next();

      StringBuffer errorMessage = new StringBuffer("Fehlende oder fehlerhafte Anmeldung: ");
      errorMessage.append(a.toString());

      Assert.assertTrue(errorMessage.toString(), isContainedInList(a, lff));
    }
  }

  private boolean isContainedInList(AnmeldungDTO a, List<AnmeldungDTO> list)
  {
    for (Iterator iter = list.iterator(); iter.hasNext(); )
    {
      AnmeldungDTO ail = (AnmeldungDTO)iter.next();

      boolean sameRunner = sameRunner(ail.getLaeufer(), a.getLaeufer());

      boolean sameNumber = ail.getStartnummer() == a.getStartnummer();
      boolean sameRunningEvent = ail.getVeranstaltung().trim().equals(a.getVeranstaltung().trim());
      boolean sameOrganization = ail.getVerein().trim().equals(a.getVerein().trim());
      boolean samePaymentStatus = ail.isBezahlt() == a.isBezahlt();

      if ((sameRunner) && (sameNumber) && (sameRunningEvent) && (sameOrganization) && (samePaymentStatus)) {
        return true;
      }
    }
    return false;
  }

  private boolean sameRunner(LaeuferDTO left, LaeuferDTO right)
  {
    boolean sameName = left.getName().trim().equals(right.getName().trim());
    boolean sameGivenname = left.getVorname().trim().equals(right.getVorname().trim());
    boolean sameStreet = left.getStrasse().trim().equals(right.getStrasse().trim());
    boolean samePostal = left.getPlz().trim().equals(right.getPlz().trim());
    boolean sameCity = left.getOrt().trim().equals(right.getOrt().trim());
    boolean sameCountry = left.getLand().trim().equals(right.getLand().trim());
    boolean sameEmail = left.getEmail().trim().equals(right.getEmail().trim());
    boolean sameYearofBirth = left.getGeburtsjahr() == right.getGeburtsjahr();
    boolean sameSex = left.getGeschlecht() == right.getGeschlecht();
    boolean sameSms = left.getSms().trim().equals(right.getSms().trim());

    if ((sameName) && (sameGivenname) && (sameStreet) && (samePostal) && 
      (sameCity) && (sameCountry) && (sameEmail) && (sameYearofBirth) && 
      (sameSex) && (sameSms)) {
      return true;
    }
    return false;
  }
}