package swa.runningeasy.junit;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import runningeasy.bom.entities.RunningServicesFactory;
import swa.runningeasy.dtos.LaufzeitDTO;
import swa.runningeasy.dtos.VeranstaltungDTO;
import swa.runningeasy.services.RunningServices;

public class Duration
{
  RunningServices s = RunningServicesFactory.getInstance();

  @Test
  public void testAnzahlLaufzeiten()
  {
    TestDataImporter tdi = new TestDataImporter();
    List veranstaltungen = tdi.getVeranstaltungen();

    for (VeranstaltungDTO veranstaltung : veranstaltungen)
    {
      List l = this.s.getLaufzeiten(veranstaltung.getName());

      StringBuffer errorMessage = new StringBuffer("Fehlerhafte Anzahl Anmeldung für Veranstaltung: ");
      errorMessage.append(veranstaltung.getName());

      if (veranstaltung.getName() == "30. Kandelberglauf 2011")
      {
        Assert.assertEquals(errorMessage.toString(), l.size(), 46L);
      }

      if (veranstaltung.getName() == "31. Kandelberglauf 2011")
      {
        Assert.assertEquals(errorMessage.toString(), l.size(), 0L);
      }
    }
  }

  @Test
  public void testInhaltLaufzeiten()
  {
    TestDataImporter tdi = new TestDataImporter();
    List veranstaltungen = tdi.getVeranstaltungen();
    Iterator localIterator2;
    for (Iterator localIterator1 = veranstaltungen.iterator(); localIterator1.hasNext(); 
      localIterator2.hasNext())
    {
      VeranstaltungDTO veranstaltung = (VeranstaltungDTO)localIterator1.next();

      List l = this.s.getLaufzeiten(veranstaltung.getName());

      List lff = tdi.getLaufzeiten();

      localIterator2 = l.iterator(); continue; LaufzeitDTO lz = (LaufzeitDTO)localIterator2.next();

      StringBuffer errorMessage = new StringBuffer("Fehlende oder fehlerhafte Anmeldung: ");
      errorMessage.append(lz.toString());

      Assert.assertTrue(errorMessage.toString(), isContainedInList(lz, lff));
    }
  }

  private boolean isContainedInList(LaufzeitDTO lz, List<LaufzeitDTO> list)
  {
    for (Iterator iter = list.iterator(); iter.hasNext(); )
    {
      LaufzeitDTO lil = (LaufzeitDTO)iter.next();

      boolean sameDuration = lil.getLaufzeit().compareTo(lz.getLaufzeit()) == 0;
      boolean sameNumber = lil.getStartnummer() == lz.getStartnummer();
      boolean sameRunningEvent = lil.getVeranstaltung().trim().equals(lz.getVeranstaltung().trim());

      if ((sameDuration) && (sameNumber) && (sameRunningEvent)) {
        return true;
      }
    }
    return false;
  }
}