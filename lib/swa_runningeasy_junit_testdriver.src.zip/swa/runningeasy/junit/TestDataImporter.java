package swa.runningeasy.junit;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import runningeasy.bom.entities.RunningServicesFactory;
import swa.runningeasy.dtos.AnmeldungDTO;
import swa.runningeasy.dtos.LaeuferDTO;
import swa.runningeasy.dtos.LaufzeitDTO;
import swa.runningeasy.dtos.VeranstaltungDTO;
import swa.runningeasy.dtos.VereinDTO;
import swa.runningeasy.services.RunningServices;

public class TestDataImporter
{
  RunningServices rs = RunningServicesFactory.getInstance();

  public void initialize()
  {
    this.rs.init();

    List veranstaltungen = getVeranstaltungen();
    List anmeldungen = getAnmeldungen();
    List laufzeiten = getLaufzeiten();
    List vereine = getVereine();
    List laeufer = getLaeufer();

    for (VereinDTO v : vereine) {
      this.rs.erzeugeVerein(v);
    }

    for (LaeuferDTO l : laeufer) {
      this.rs.erzeugeLaeufer(l);
    }

    for (VeranstaltungDTO veranstaltung : veranstaltungen) {
      this.rs.erzeugeVeranstaltung(veranstaltung);
    }

    for (AnmeldungDTO anmeldung : anmeldungen) {
      this.rs.erzeugeAnmeldung(anmeldung);
    }

    for (LaufzeitDTO laufzeit : laufzeiten)
      this.rs.erzeugeLaufzeit(laufzeit);
  }

  List<VereinDTO> getVereine()
  {
    List ret = new ArrayList();
    List vereine = getRowsInTable("vereine.csv");
    for (String s : vereine) {
      String[] strings = s.split(";");
      VereinDTO v = new VereinDTO(strings[0]);
      ret.add(v);
    }
    return ret;
  }

  List<LaeuferDTO> getLaeufer() {
    List ret = new ArrayList();
    List laeufer = getRowsInTable("laeufer.csv");

    for (String s : laeufer) {
      String[] strings = s.split(";");
      String[] name_vorname = strings[0].split(",");
      LaeuferDTO l = null;
      l = new LaeuferDTO(name_vorname[0], name_vorname[1], new Integer(strings[2].trim()).intValue(), 
        strings[3].charAt(0), "", "", "", "", "", "");

      ret.add(l);
    }
    return ret;
  }

  List<VeranstaltungDTO> getVeranstaltungen()
  {
    List ret = new ArrayList();
    List veranstaltungen = getRowsInTable("veranstaltungen.csv");

    SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy");
    for (String s : veranstaltungen) {
      String[] strings = s.split(";");
      VeranstaltungDTO v = null;
      try {
        v = new VeranstaltungDTO(strings[0], df.parse(strings[1]), df.parse(strings[2]), new Integer(strings[3].trim()).intValue());
      } catch (NumberFormatException e) {
        e.printStackTrace();
      } catch (ParseException e) {
        e.printStackTrace();
      }
      ret.add(v);
    }
    return ret;
  }

  List<AnmeldungDTO> getAnmeldungen()
  {
    List ret = new ArrayList();
    List veranstaltungen = getRowsInTable("anmeldungen.csv");

    for (String s : veranstaltungen) {
      String[] strings = s.split(";");
      String[] name_vorname = strings[0].split(",");
      LaeuferDTO l = null;
      l = new LaeuferDTO(name_vorname[0], name_vorname[1], new Integer(strings[2].trim()).intValue(), 
        strings[3].charAt(0), strings[4], strings[5], strings[6], strings[7], strings[8], strings[9]);
      AnmeldungDTO a = new AnmeldungDTO(l, new Boolean(strings[10]).booleanValue(), strings[11], strings[12], 
        new Integer(strings[13].trim()).intValue());

      ret.add(a);
    }
    return ret;
  }

  List<LaufzeitDTO> getLaufzeiten() {
    List ret = new ArrayList();
    List laufzeiten = getRowsInTable("laufzeiten.csv");

    for (String s : laufzeiten) {
      String[] strings = s.split(";");
      LaufzeitDTO l = null;
      SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
      try
      {
        l = new LaufzeitDTO(new Integer(strings[0].trim()).intValue(), 
          df.parse(strings[1]), strings[2]);
      } catch (NumberFormatException e) {
        e.printStackTrace();
      } catch (ParseException e) {
        e.printStackTrace();
      }
      ret.add(l);
    }
    return ret;
  }

  private List<String> getRowsInTable(String file)
  {
    List ret = new ArrayList();
    try
    {
      BufferedReader in = getReadFromJar(file);

      String line = null;
      while ((line = in.readLine()) != null) {
        ret.add(line);
      }
      in.close();
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    return ret;
  }

  private BufferedReader getReadFromJar(String file)
  {
    Class thisClass = getClass();
    ClassLoader cl = thisClass.getClassLoader();
    InputStream is = cl.getResourceAsStream(file);
    InputStreamReader isr = new InputStreamReader(is);
    BufferedReader in = new BufferedReader(isr);

    return in;
  }
}