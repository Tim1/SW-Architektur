package swa.runningeasy.junit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@Suite.SuiteClasses({Initialize.class, Resultlist.class, RunningEvent.class, Organization.class, Runner.class, Application.class, Duration.class})
public class AllTests
{
}